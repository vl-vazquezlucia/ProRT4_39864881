import mysqlConnection from 'mysql2/promise';

const properties = {
    host:'localhost',
    user:'root',
    password:'',
    port: '3308',
    database:'libros'
};

export const pool = mysqlConnection.createPool(properties);