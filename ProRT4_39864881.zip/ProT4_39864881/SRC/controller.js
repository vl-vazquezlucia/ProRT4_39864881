import {pool} from './database.js';

class LibroController{

  async getAll (req,res){
    const [result] = await pool.query('SELECT * FROM libros')
    res.json(result);
  }

  async getOne(req, res) {
    const { id } = req.params;
    try {
      const [result] = await pool.query('SELECT * FROM libros WHERE id = ?', [
        id,
      ]);

      if (result.length === 0) {
        
        res.status(404).json({ message: "Libro no encontrado" });
      } else {
        res.json(result[0]);
      }
    } catch (error) {
      res.status(500).json({ message: "Error al obtener el libro", error });
    }
  }

  async add(req, res) {
    try {
      const { titulo, autor, categoria, fecha_publicacion, isbn } = req.body;
  
      // Validar que el ISBN solo contenga 13 caracteres numéricos
      const isbnRegex = /^\d{1,13}$/;
      if (!isbnRegex.test(isbn)) {
        return res.status(400).json({ message: "El campo ISBN solo admite números y debe tener como maximo 13 dígitos." });
      }
  
      // Si la validación es correcta, se inserta el libro en la base de datos
      const [result] = await pool.query(
        `INSERT INTO libros(titulo, autor, categoria, fecha_publicacion, isbn) VALUES (?, ?, ?, ?, ?)`,
        [titulo, autor, categoria, fecha_publicacion, isbn]
      );
  
      res.json({ "Id insertado": result.insertId });
    } catch (error) {
      res.status(500).json({ message: "Error al agregar el libro", error });
    }
  }
  

    async delete (req,res){
      try {
      const libro = req.body;
      const [result] =await pool.query(`DELETE FROM libros WHERE isbn=(?)`,[libro.isbn]);
      res.json({"Registros eliminados": result.affectedRows}); 
    } 
    catch (error) {
      console.error('Error al eliminar el libro:', error);
      res.status(500).json({ mensaje: 'Ocurrió un error al intentar eliminar el libro.' });
    }
  }


    async update (req,res){
      try {
      const libro = req.body;
      const [result] =await pool.query(`UPDATE libros SET titulo=?, autor=?, categoria=?, fecha_publicacion=?, isbn=? WHERE id=?`,
        [libro.titulo,libro.autor,libro.categoria,libro.fecha_publicacion,libro.isbn,libro.id]);
      res.json({"Registros actualizados": result.changedRows}); 
    } catch (error) {
      console.error('Error al actualizar el libro:', error);
      res.status(500).json({ mensaje: 'Ocurrió un error al intentar actualizar el libro.' });
    }
  }
}

export const libro = new LibroController();